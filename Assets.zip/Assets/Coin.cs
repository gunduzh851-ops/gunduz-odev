using UnityEngine;

public class Coin : MonoBehaviour
{
    private bool collected = false;
    private CoinManager coinManager;

    void Start()
    {
        coinManager = FindFirstObjectByType<CoinManager>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (collected) return;

        if (other.CompareTag("Player"))
        {
            collected = true;

            if (coinManager != null)
            {
                coinManager.CollectCoin();
            }

            gameObject.SetActive(false);
        }
    }
}

