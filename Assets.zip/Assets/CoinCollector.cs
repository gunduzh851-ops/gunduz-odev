using UnityEngine;
using UnityEngine.SceneManagement;

public class CoinCollector : MonoBehaviour
{
    private GameObject[] coins;     // Sahnedeki t�m coinleri tutar
    private int coinsCollected = 0;
    private bool levelLoaded = false;

    public string nextLevel = "Level2";  // Ge�ilecek sahne ismi

    void Start()
    {
        // Sahnedeki t�m coin objelerini bul
        coins = GameObject.FindGameObjectsWithTag("Coin");
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (levelLoaded) return;  // Level zaten y�klendiyse ��k

        // Sadece tag = Coin olan objeler i�in
        if (other.CompareTag("Coin"))
        {
            // Coin zaten yok edilmi�se tekrar sayma
            if (!other.gameObject.activeSelf) return;

            other.gameObject.SetActive(false);  // Coin�i g�r�nmez yap
            coinsCollected++;

            Debug.Log("Coins collected: " + coinsCollected + " / " + coins.Length);

            // E�er t�m coinler topland�ysa Level2�ye ge�
            if (coinsCollected >= coins.Length)
            {
                levelLoaded = true;
                SceneManager.LoadScene(nextLevel);
            }
        }
    }
}
