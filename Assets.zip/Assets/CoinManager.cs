using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class CoinManager : MonoBehaviour
{
    public TMP_Text coinText;
    public int totalCoins = 10;

    private int currentCoins = 0;

    void Start()
    {
        UpdateCoinText();
    }

    public void CollectCoin()
    {
        currentCoins++;
        UpdateCoinText();

        if (currentCoins >= totalCoins)
        {
            SceneManager.LoadScene("Level2");

        }
    }

    void UpdateCoinText()
    {
        if (coinText != null)
        {
            coinText.text = currentCoins + " / " + totalCoins;
        }
    }
}
